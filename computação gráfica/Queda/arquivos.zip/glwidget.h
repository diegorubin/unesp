#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QtOpenGL/QGLWidget>
#include <QtCore/QTimer>
#include <GL/glut.h>

#include "Calculos.h"

#include <math.h>

class GLWidget : public QGLWidget
{
Q_OBJECT

public:
    GLWidget(QWidget *parent = 0);
    ~GLWidget();

    double getAltura();
    double getVelocidade();

    double setAltura(double Altura);
    double setGravidade(double gravidade);
    void setCoeficienteRestituicao(double coeficiente);

private:
    int instante;
    GLfloat angle;
    GLfloat fAspect;
    GLfloat posicao_bolinha;
    GLfloat Xsize,Ysize;

    bool subindo;

    double g,Altura,Velocidade;
    double bounce;
    double temp;

    double AlturaInicial;
    double VelocidadeInicial;

    double e;

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int w, int h);

private slots:
    void anima();

};

#endif // GLWIDGET_H
