/*
 * Calculos.cpp
 *
 *  Created on: 05/07/2009
 *      Author: diego
 */

#include "Calculos.h"

Calculos::Calculos() {
	// TODO Auto-generated constructor stub

}

Calculos::~Calculos() {
	// TODO Auto-generated destructor stub
}

double Calculos::espaco(double espaco_inicial,double velocidade_inicial,double instante,double aceleracao)
{
	instante = instante/100;
	return (espaco_inicial + velocidade_inicial*instante + (aceleracao*instante*instante)/2);
}

double Calculos::velocidade(double velocidade_inicial,double instante,double aceleracao)
{
	instante = instante/100;
	return (velocidade_inicial + (instante*aceleracao)/2);
}
