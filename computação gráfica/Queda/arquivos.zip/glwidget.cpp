#include "glwidget.h"

GLWidget::GLWidget(QWidget *parent)
: QGLWidget(parent)
{
	AlturaInicial = 170;
	VelocidadeInicial = 0;
	instante = 0;
	subindo = false;

	g = 9.8;
	Velocidade = 0;
	e = 0.5;

	QTimer *timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(anima()));
	timer->start(100);
}
GLWidget::~GLWidget()
{
    makeCurrent();
    glDeleteLists(angle, 1);
    glDeleteLists(fAspect, 1);
    glDeleteLists(posicao_bolinha, 1);
    glDeleteLists(Xsize, 1);
    glDeleteLists(Ysize,1);

}
void GLWidget::initializeGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    angle=45;
}

double GLWidget::getAltura()
{
	return Altura;
}

double GLWidget::getVelocidade()
{
	return Velocidade;
}

void GLWidget::setCoeficienteRestituicao(double coeficiente)
{
	e = coeficiente;
}

void GLWidget::paintGL()
{
	glPushMatrix();
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0f, 0.0f, 1.0f);
	if (Altura <= 10)
		Ysize =1/(1+(0.07*(10-Altura)));
	else
		Ysize =1;
	Xsize =2-Ysize;
	glScalef(Xsize, Ysize, Xsize);

	glTranslatef(0,Altura,0);
	glutSolidSphere(5.0f,20,20);

	glPopMatrix();
}

void GLWidget::resizeGL(int w, int h)
{
    // Para previnir uma divisão por zero
    if ( h == 0 ) h = 1;

    // Especifica o tamanho da viewport
    glViewport(0, 0, w, h);

    // Calcula a correção de aspecto
    fAspect = (GLfloat)w/(GLfloat)h;

    //parametros de visualizacao
    // Especifica sistema de coordenadas de projeção
    glMatrixMode(GL_PROJECTION);
    // Inicializa sistema de coordenadas de projeção
    glLoadIdentity();

    // Especifica a projeção perspectiva
    gluPerspective(angle,fAspect,0.1,500);

    // Especifica sistema de coordenadas do modelo
    glMatrixMode(GL_MODELVIEW);
    // Inicializa sistema de coordenadas do modelo
    glLoadIdentity();

    // Especifica posição do observador e do alvo
    gluLookAt(0,160,200, 0,100,0, 0,1,0);
}

void GLWidget::anima()
{
	instante = instante + 10;
	if(subindo) //quando esta voltando
	{
		Altura = Calculos::espaco(0,VelocidadeInicial,instante,g);
		Velocidade = Calculos::velocidade(VelocidadeInicial,instante,g*-1);
		if(Velocidade<=0)
		{
			subindo = false;
			AlturaInicial = Altura;
			instante = 0;
		}
	}
	else //quando esta caindo
	{
		Altura = Calculos::espaco(AlturaInicial,0,instante,g*-1);
		Velocidade = Calculos::velocidade(0,instante,g);
		if(Altura <=0){
			subindo = true;
			VelocidadeInicial = Velocidade * e;//calculo para colisao
			instante = 0;
		}
	}
	updateGL();
}

