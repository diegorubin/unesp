#include "queda.h"

Queda::Queda(QWidget *parent)
    : QWidget(parent)
{
	ui.setupUi(this);
	ui.sclGL->setWidget(&glWidget);
	QTimer *timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(getInfs()));
	timer->start(100);
}

Queda::~Queda()
{

}

void Queda::getInfs()
{
	ui.lblAltura->setText(QString::number(glWidget.getAltura()) + " m");
	ui.lblVelocidade->setText(QString::number(glWidget.getVelocidade()) + " m/s");
}
